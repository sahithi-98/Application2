package com.cg.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.bean.Hbean;
import com.cg.dao.Hdao;
import com.cg.exception.HException;

public class HTest {
	
	static Hdao dao;
	static Hbean hbean;
	
	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new Hdao();
		hbean = new Hbean();
	}

	
	@Test
	public void testaddDetails() throws Exception
	{
		/*hbean.setPatientName("Gem");
		hbean.setPatientAge(24);
		hbean.setPatientPhoneNumber("9823452413");
		hbean.setDescription("bcd");*/
		//hbean.setConsultationDate(s);
		
		assertEquals("1013",dao.addPatientdetails(hbean));
	}
	

}
