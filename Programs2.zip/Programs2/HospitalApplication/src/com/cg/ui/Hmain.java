package com.cg.ui;

import java.util.Scanner;


import com.cg.bean.Hbean;
import com.cg.exception.HException;
import com.cg.service.HService;

public class Hmain {
	static Hbean hbean = null;
	static HService hs = null;
	static Scanner s = new Scanner(System.in);
	public static void main(String[] args) throws Exception {
		String PatientId;
		
		while(true)
		{
			System.out.println("Welcome to Hmain:");
			System.out.println("Select the option");
			System.out.println("1.Add details");
			System.out.println("2.View details");
			//System.out.println("3.Retrieve all details");
			System.out.println("3.Exit");
			int option = s.nextInt();
			switch(option)
			{
			case 1:
				while(hbean==null)
				{
					hbean = populateBean();
				}
				try
				{
				hs = new HService();
				PatientId = hs.addPatientdetails(hbean);

				System.out.println("Donator details  has been successfully registered ");
				System.out.println("Donator  ID Is: " + PatientId);
				}
				catch(HException e)
				{
					System.out.println(e);
				}
				break;
				
			case 2:
				hs = new HService();
				System.out.println("Enter the patientId:");
				PatientId = s.next();
				hbean = getPatientDetails(PatientId);
				System.out.println(hbean);
			default:
				System.exit(0);
				
			}
			
		}

	}

	private static Hbean getPatientDetails(String patientId) throws Exception {
		
		
		HService hs = new HService();
		hbean = hs.getPatientDetails(patientId);
		return hbean;
	}

	private static Hbean populateBean() {
		
		Hbean hbean = new Hbean();
		
		System.out.println("Enter Patient name:");
		hbean.setPatientName(s.next());
		System.out.println("Enter Patient Age:");
		hbean.setPatientAge(s.nextInt());
		System.out.println("Enter mobile no:");
		hbean.setPatientPhoneNumber(s.nextLong());
		System.out.println("Enter Description:");
		hbean.setDescription(s.next());
		
		// TODO Auto-generated method stub
		return hbean;
	}

}
