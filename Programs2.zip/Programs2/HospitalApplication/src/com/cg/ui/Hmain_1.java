package com.cg.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bean.Hbean;
import com.cg.exception.HException;
import com.cg.service.HService;

public class Hmain {
	static Hbean hbean = null;
	static HService hs = new HService();
	static Scanner s = new Scanner(System.in);
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws Exception {
		PropertyConfigurator.configure("Resources//log4j.properties");
		
		String PatientId;
		
		while(true)
		{
			System.out.println("Welcome to Hmain:");
			System.out.println("Select the option");
			System.out.println("1.Add details");
			System.out.println("2.View details");
			System.out.println("3.Retrieve all details");
			System.out.println("4.Exit");
			int option = s.nextInt();
			
			switch(option)
			{
			case 1:
				while(hbean==null)
				{
					hbean = populateBean();
				}
				try
				{
				hs = new HService();
				PatientId = hs.addPatientdetails(hbean);
				System.out.println("Donator details  has been successfully registered ");
				System.out.println("Donator  ID Is: " + PatientId);
				
				}
				catch(HException e)
				{
					logger.error("exception occured"+e.getMessage());
					System.out.println(e);
				}
				finally
				{
					hs = null;
					PatientId = null;
					hbean = null;
				}
				break;
				
			case 2:
				try {
				hs = new HService();
				System.out.println("Enter the patientId:");
				PatientId = s.next();
				hbean = getPatientDetails(PatientId);
				System.out.println(hbean);
				}
				catch(HException e)
				{
					logger.error("exception occured"+e.getMessage());
					System.out.println(e);
				}
				finally
				{
					hs = null;
					hbean = null;
				}
				break;
			case 3:
				try
				{
				hs = new HService();
				List<Hbean> hlist = hs.retrieveAll();
				Iterator it = hlist.iterator();
				while(it.hasNext())
				{
					System.out.println(it.next());

				}
				}
				catch(HException e)
				{
					logger.error("exception occured"+e.getMessage());
					System.out.println(e);
				}
				finally
				{
					hs = null;
					hbean = null;
				}
				break;
			case 4:
				System.out.println("Exiting Application..");
				System.exit(0);
			default:
				System.out.println("Enter a valid option..");
				
			}
			
		}

	}

	private static Hbean getPatientDetails(String patientId) throws Exception {
		
		
		HService hs = new HService();
		try {
		hbean = hs.getPatientDetails(patientId);
		}
		catch(HException e)
		{
			logger.error("exception occured"+e.getMessage());
			System.out.println(e);
		}
		finally
		{
			hs = null;
		}
		return hbean;
	}

	private static Hbean populateBean() {
		
		Hbean hbean = new Hbean();
		
		System.out.println("Enter Patient name:");
		hbean.setPatientName(s.next());
		System.out.println("Enter Patient Age:");
		hbean.setPatientAge(s.nextInt());
		System.out.println("Enter mobile no:");
		hbean.setPatientPhoneNumber(s.next());
		System.out.println("Enter Description:");
		hbean.setDescription(s.next());
		
		// TODO Auto-generated method stub
		return hbean;
	}

}
