package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bean.Hbean;
import com.cg.connection.Conn;

public class Hdao implements IHdao{
	
	Logger logger=Logger.getRootLogger();
	public Hdao()
	{
		PropertyConfigurator.configure("Resources//log4j.properties");
	}

	@Override
	public String addPatientdetails(Hbean hbean) throws Exception {
		
		
		
		String PatientId = null;
		try
		{
		Connection con = null;
		con = Conn.getConnection();
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		ResultSet rs = null;
		ps = con.prepareStatement(QuickMapper.INSERT_QUERY);
		ps.setString(1, hbean.getPatientName());
		ps.setInt(2, hbean.getPatientAge());
		ps.setString(3, hbean.getPatientPhoneNumber());
		ps.setString(4, hbean.getDescription());
		 ps.executeUpdate();
		 
		ps1 = con.prepareStatement(QuickMapper.PATIENTID_QUERY_SEQUENCE);
		rs = ps1.executeQuery();
		if(rs.next())
		{
			PatientId = rs.getString(1);
		}
		}
		catch(SQLException e)
		{
			System.out.println(e);
			logger.error(e.getMessage());
		}
		return PatientId;
		
	}

	@Override
	public Hbean getPatientDetails(String patientId) throws Exception {
		
		Hbean hbean = new Hbean();
		try
		{
		Connection con;
		con = Conn.getConnection();
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		ResultSet rs = null;
		
		ps = con.prepareStatement(QuickMapper.VIEW_PATIENT_DETAILS_QUERY);
		ps.setString(1, patientId);
		rs = ps.executeQuery();
		//System.out.println(rs);
		if(rs.next())
		{
			hbean.setPatientId(rs.getInt(1));
			hbean.setPatientName(rs.getString(2));
			hbean.setPatientAge(rs.getInt(3));
			hbean.setPatientPhoneNumber(rs.getString(4));
			hbean.setDescription(rs.getString(5));
			hbean.setConsultationDate(rs.getDate(6));
			
			System.out.println(rs.getDate(6));
		}
		}
		catch(SQLException e)
		{
			System.out.println(e);
			logger.error(e.getMessage());
		}
		return hbean;

}

	@Override
	public List<Hbean> retrieveAll() throws Exception {
		
		List<Hbean> hlist = new ArrayList<Hbean>();
		try
		{
		Connection con;
		con = Conn.getConnection();
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		ResultSet rs = null;
		
		ps = con.prepareStatement(QuickMapper.RETRIVE_ALL_QUERY);
		rs = ps.executeQuery();
		
		
		while(rs.next())
		{
			Hbean hbean = new Hbean();
			hbean.setPatientId(rs.getInt(1));
			hbean.setPatientName(rs.getString(2));
			hbean.setPatientAge(rs.getInt(3));
			hbean.setPatientPhoneNumber(rs.getString(4));
			hbean.setDescription(rs.getString(5));
			hbean.setConsultationDate(rs.getDate(6));
			hlist.add(hbean);
		}		
		}catch(SQLException e)
		{
			System.out.println(e);
			logger.error(e.getMessage());
		}
		return hlist;
}
}
