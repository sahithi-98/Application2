package com.cg.dao;

import java.util.List;

import com.cg.bean.Hbean;

public interface IHdao {
	String addPatientdetails(Hbean patient) throws Exception;
	Hbean getPatientDetails(String patientId) throws Exception;
	public List<Hbean> retrieveAll() throws Exception;
}
