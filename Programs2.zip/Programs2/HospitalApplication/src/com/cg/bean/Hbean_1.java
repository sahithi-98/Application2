package com.cg.bean;

import java.sql.Date;

public class Hbean {
	int PatientId;
	String PatientName;
	int PatientAge;
	String PatientPhoneNumber;
	String Description;
	Date ConsultationDate;
	public int getPatientId() {
		return PatientId;
	}
	public void setPatientId(int patientId) {
		PatientId = patientId;
	}
	public String getPatientName() {
		return PatientName;
	}
	public void setPatientName(String patientName) {
		PatientName = patientName;
	}
	public int getPatientAge() {
		return PatientAge;
	}
	public void setPatientAge(int patientAge) {
		PatientAge = patientAge;
	}
	public String getPatientPhoneNumber() {
		return PatientPhoneNumber;
	}
	public void setPatientPhoneNumber(String patientPhoneNumber) {
		PatientPhoneNumber = patientPhoneNumber;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public Date getConsultationDate() {
		return ConsultationDate;
	}
	@Override
	public String toString() {
		return "Hbean [PatientId=" + PatientId + ", PatientName=" + PatientName + ", PatientAge=" + PatientAge
				+ ", PatientPhoneNumber=" + PatientPhoneNumber + ", Description=" + Description + ", ConsultationDate="
				+ ConsultationDate + "]";
	}
	public void setConsultationDate(Date date) {
		ConsultationDate = date;
	}

}
