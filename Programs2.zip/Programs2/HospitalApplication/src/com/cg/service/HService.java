package com.cg.service;

import com.cg.bean.Hbean;
import com.cg.dao.Hdao;

public class HService implements IHservice{

	@Override
	public String addPatientdetails(Hbean patient) throws Exception {
		
		Hdao hdao = new Hdao();
		String PId;
		PId = hdao.addPatientdetails(patient);
		return PId;
	}

	@Override
	public Hbean getPatientDetails(String patientId) throws Exception {
		Hdao hdao = new Hdao();
		Hbean hbean = null;
		hbean = hdao.getPatientDetails(patientId);
		
		return hbean;
	}

}
