##Please run the below DDL query before you execute this application.  

CREATE TABLE studentsr
(studentid NUMBER(6),
name VARCHAR2(25));
